package simulator;

import beans.BookBean;
import beans.ClientBean;
import beans.ContributorBean;
import beans.LibraryBean;

import java.util.ArrayList;
import java.util.Iterator;

/*
 *
 * This class simulates the library behavior as per the requirements of the assignments
 *
 * */
public class SimulationMethods {

    LibraryBean library = new LibraryBean();

    /*
     *
     * This method adds 3 books to the library, those books are contributed by a member
     *
     * */

    public ArrayList<BookBean> addBooksInLiberay() {

        library.addBook(new BookBean("Book of Life",
                new ContributorBean("Adam"),
                "Peterson Jack", 1970, true));
        library.addBook(new BookBean("Book of Science", new ContributorBean("Edith"),
                "Peterson Adam", 1972, true));
        library.addBook(new BookBean("Book of Creativity", new ContributorBean("Stephen"),
                "Peterson John", 1974,
                true));
        return library.getAllBooks();

    }


    /*
     *
     * This method adds 2 clients to the system with different names
     *
     * */

    public ArrayList<ClientBean> clients() {

        ArrayList<ClientBean> clients = new ArrayList<>();
        clients.add(new ClientBean("Anna"));
        clients.add(new ClientBean("Katja"));
        return clients;

    }


    /*
     *
     * This method rents the books to the clients and each book that is rented
     * gets removed from the library and is no more physically present in the library
     * first we rent all books for a client and then when second client tries to rent a book
     * it is not given because there are no more physical books present in the library
     * so it throws an Exception, which I handled so that program behaves accordingly
     * */

    public void rentBooksToClients(ArrayList<ClientBean> clients, ArrayList<BookBean> books) throws Exception {
        //client assignment creation
        ClientBean firstClient = clients.get(0);
        ClientBean secondClient = clients.get(1);

        //renting all books for one client
        for (Iterator<BookBean> iterator = books.iterator(); iterator.hasNext(); ) {
            BookBean book = iterator.next();
            firstClient.rentBook(book);
            iterator.remove(); //once book is rented, we remove it from library
            book.setPhysicallyPresent(false);
        }

        //renting book zero for second client, we can rent any book, since no books are available it must throw a Exception which is handled
        secondClient.rentBook(books.get(0));

    }
}
