import beans.BookBean;
import beans.LibraryBean;
import simulator.SimulationMethods;

/*
    This class performs the simulation task
*/

public class Main {

    public static void main(String[] args) {
        //Main Task, The Simulation
        SimulationMethods simulation = new SimulationMethods();
        try {
            /*
                Perform the simulations, clients method generates the clients, addBooksInLibrary method contributes books in the liberay,
                rentBooksToClients method checks the necessary conditions for the books to be rented to the clients and once conditions meet
                books are rented to the clients and their physical availability is changed to the false
            */
            simulation.rentBooksToClients(simulation.clients(), simulation.addBooksInLiberay());
        } catch (Exception ex) {
            /*
                In case there are no books and we try to rent a book to clients than an exception is thrown which is handled here,
                showing the correct message for the user
            */
            System.out.println("Library has no physical book available, please come later");
        }

        //Subsidiary task to check the functionality of searchingFunctions
        //This can be done in the main task too, since we are not asked to do so,
        //that's why we are doing it in the end, to show the working of it
        LibraryBean libraryBean = new LibraryBean();

        //Adding books in the library
        for (BookBean book : simulation.addBooksInLiberay()) {
            libraryBean.addBook(book);
        }

        //Searching Books by the names
        System.out.println("\n-----NOW BOOK SEARCH BY NAME-----");
        libraryBean.searchBooksByName("Book of Life");
        System.out.print("\n");

        //Searching Books by the Age (Today - Publication Year)
        System.out.println("-----NOW BOOK SEARCH BY AGE-----");
        libraryBean.searchBooksByAge(40);
        System.out.print("\n");

        //Searching Books by the Author
        System.out.println("-----NOW BOOK SEARCH BY AUTHOR-----");
        libraryBean.searchBooksByAuthor("Peterson John");
        System.out.print("\n");

        //Searching Books by the Contributor
        System.out.println("-----NOW BOOK SEARCH BY CONTRIBUTOR-----");
        libraryBean.searchBooksByContributor("Edith");
    }
}
