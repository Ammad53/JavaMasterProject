package beans;

import java.util.ArrayList;

//This class is used for the contributors, each contributor can have many books
public class ContributorBean {
    private String contributorName;
    private ArrayList<BookBean> booksContributed = new ArrayList<>();

    public ContributorBean(String contributorName) {
        this.contributorName = contributorName;
    }

    public String getContributorName() {
        return contributorName;
    }

    public ArrayList<BookBean> getBooksContributed() {
        return booksContributed;
    }
}
