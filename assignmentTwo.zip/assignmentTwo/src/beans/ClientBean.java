package beans;

import java.util.ArrayList;


/*
    This class serves the purpose of the client functionality
*/

public class ClientBean {

    private String clientName;

    private ArrayList<BookBean> booksRent = new ArrayList<>();

    /*
        This method takes care of the renting a book to the client also verifying if the book is physically present and books rented are not more than 19
    */

    public void rentBook(BookBean book) {
        if (book.isPhysicallyPresent()) {
            if (booksRent.size() < 19) {
                booksRent.add(book);
                System.out.println("Book [" + book.getBookName() + "] is rented by the client [" + clientName + "]");
            } else {
                System.out.println("Book rented limit is over, please return to continue the renting of books");
            }
        } else {
            System.out.println("Book [" + book.getBookName() + "] is physically not available, please check later");
        }
    }

    /*
          This method takes care of the creating a new client
    */
    public ClientBean(String clientName) {
        this.clientName = clientName;
        System.out.println("A new client [" + clientName + "] has joined the library");
    }

    /*
          This method returns all the books rented by the client
    */

    public ArrayList<BookBean> getBooksRent() {
        System.out.println("all available books rented");
        return booksRent;
    }

}
