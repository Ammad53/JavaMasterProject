package beans;

import java.util.ArrayList;
import java.util.Calendar;

/*
    This class takes care of the library functionality
*/

public class LibraryBean {

    private ArrayList<BookBean> allBooks = new ArrayList<>();

    /*
        This method is used get all the books in the library
    */
    public ArrayList<BookBean> getAllBooks() {
        System.out.println("Books available in library are : ");
        for (BookBean book : this.allBooks) {
            System.out.println("Book named --> " + "[" + book.getBookName() + "]");
        }
        return allBooks;
    }

     /*
        This method is used add a new book in the library
    */

    public void addBook(BookBean book) {
        allBooks.add(book);
    }

    /*
        This method is used to remove a book from the library
    */
    public void removeBook(BookBean book) {
        allBooks.add(book);
    }

    /*
        This method is used for searching books by the name from the library
    */
    public ArrayList<BookBean> searchBooksByName(String name) {
        ArrayList<BookBean> result = new ArrayList<>();
        for (BookBean book : this.allBooks) {
            if (book.getBookName().equals(name)) {
                result.add(book);
            }
        }
        if (result.size() > 0) {
            System.out.println("Books found by name are : ");
            for (BookBean book : result) {
                System.out.println(book.getBookName());
            }
        } else {
            System.out.println("No books available with this name");
        }
        return result;
    }

    /*
        This method is used for searching books by the contributor from the library
    */

    public ArrayList<BookBean> searchBooksByContributor(String contributor) {
        ArrayList<BookBean> result = new ArrayList<>();
        for (BookBean book : this.allBooks) {
            if (book.getContributorName().equals(contributor)) {
                result.add(book);
            }
        }

        if (result.size() > 0) {
            System.out.println("Books found by contributor name are : ");
            for (BookBean book : result) {
                System.out.println(book.getBookName());
            }
        } else {
            System.out.println("No books available with this contributor name");
        }
        return result;
    }

    /*
        This method is used for searching books by the author from the library
    */

    public ArrayList<BookBean> searchBooksByAuthor(String author) {
        ArrayList<BookBean> result = new ArrayList<>();
        for (BookBean book : this.allBooks) {
            if (book.getAuthorName().equals(author)) {
                result.add(book);
            }
        }
        if (result.size() > 0) {
            System.out.println("Books found by author name are : ");
            for (BookBean book : result) {
                System.out.println(book.getBookName());
            }
        } else {
            System.out.println("No books available with this author name");
        }
        return result;
    }

    /*
        This method is used for searching books by the age of the books calculated by the publication year from the library
    */

    public ArrayList<BookBean> searchBooksByAge(int age) {
        ArrayList<BookBean> result = new ArrayList<>();
        for (BookBean book : this.allBooks) {
            if ((Calendar.getInstance().get(Calendar.YEAR) - book.getPublishYear()) == age) {
                result.add(book);
            }
        }
        if (result.size() > 0) {
            System.out.println("Books found by age are : ");
            for (BookBean book : result) {
                System.out.println(book.getBookName());
            }
        } else {
            System.out.println("No books available with this age");
        }
        return result;
    }


}
