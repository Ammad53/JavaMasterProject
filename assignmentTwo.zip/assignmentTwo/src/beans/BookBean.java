package beans;

/*
   This class is simply a bean/pojo class which has fields and a constructor to handle the class books in the liberaries
*/

public class BookBean {

    private String bookName;
    private ContributorBean contributor;
    private String authorName;
    private int publishYear;
    private boolean physicallyPresent;

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getContributorName() {
        return contributor.getContributorName();
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public int getPublishYear() {
        return publishYear;
    }

    public void setPublishYear(int publishYear) {
        this.publishYear = publishYear;
    }

    /*
        This constructor with all the fields is used for the books to be put in the library and for the simulation purpose, it
        also contains logging for the user to see on the console when there's a book created
    */
    public BookBean(String bookName, ContributorBean contributor, String authorName,
                    int publishYear, boolean physicallyPresent) {
        this.bookName = bookName;
        this.contributor = contributor;
        this.physicallyPresent = physicallyPresent;
        this.authorName = authorName;
        this.publishYear = publishYear;
        System.out.println("A new book " +
                "[" + bookName + "] contributed by the [" + contributor.getContributorName() + "]");
    }

    public String getBookName() {
        return bookName;
    }

    public boolean isPhysicallyPresent() {
        return physicallyPresent;
    }

    public void setPhysicallyPresent(boolean physicallyPresent) {
        this.physicallyPresent = physicallyPresent;
    }
}
